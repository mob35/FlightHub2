'use strict';

/**
 * @ngdoc function
 * @name inflightHubApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the inflightHubApp
 */
angular.module('inflightHubApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
